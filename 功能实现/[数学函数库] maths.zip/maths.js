/* 功能实现/数学函数库
 *
 * [函数库类型：使用 `const maths = require('./maths.js');` 来使用]
 * 
 * 功能：数学函数库
 * 作者：CodeZhangBorui
 * 最近更新时间：2021-2-26
 *
 * 前置函数库：无
 * [注意：如果缺少前置函数库，会导致找不到函数等错误]
 * 
 * 后置函数库：[跑酷基本函数库]rungo.js
 * 
 * 
 * 使用方法
 * 1. `maths.format(Number val)`：将数字四舍五入到两位小数
 * 2. `maths.randomInt(Number min, Number max)`：在min与max之间随机选择一个整数
 */

format=(val)=>{return Math.round(val * 100) / 100;};//四舍五入
randomInt=(min,max)=>{return Math.floor(Math.random() * (max - min + 1)) + min;};//随机整数

module.exports = {
    format,
    randomInt
}