/* 功能实现/跑酷基本函数库
 *
 * [函数库类型：使用 `const rungo = require('./rungo.js');` 来使用]
 * 
 * 功能：跑酷基本函数库
 * 作者：CodeZhangBorui
 * 最近更新时间：2021-2-26
 *
 * 前置函数库：[数学函数库]maths.js
 * [注意：如果缺少前置函数库，会导致找不到函数等错误]
 * 
 * 后置函数库：无
 * 
 * 使用方法
 * 1. `rungo.start(entity entity)`：当前玩家的跑酷开始计时并立即存档一次，同时下面的函数将启用，玩家将不能飞行
 * 2. `rungo.save(entity entity)`：将玩家当前位置记录为存档点
 * 3. `rungo.backrun(entity entity)`：使玩家立即返回存档点
 * 4. `rungo.end(entity entity)`：使玩家结束跑酷，结束计时并广播，同时save、backrun将无法使用（如果禁用了再次跑酷的话，start也将无法使用）
 */

/*配置指南：
 * flyAfterEnd：是否可以在结束后飞行
 * canAgain：是否可以再跑一次
 * 下面是配置选项
 */
const flyAfterEnd = true;
const canAgain = true;

const maths = require('./maths.js');//前置函数库 maths.js
function MakePostion(x,y,z){return new Box3Vector3(x,y,z);}//Box3Vector3
var time = 0;//计时器 毫秒
var timeS = 0;//计时器 秒

function zeroTime(entity) {entity.player.Ntime = timeS;}//归零计时器
function getTime(entity) {return timeS - entity.player.Ntime;}//获取计时器
world.onTick((tickEvent) => {time += tickEvent.elapsedTimeMS;timeS = time/1000;});//开始计时器

start=(entity)=>{
    x = entity.position.x;
    y = entity.position.y;
    z = entity.position.z;
    world.say(`${entity.player.name} 出发了！`);
    entity.player.spawnPoint = MakePostion(x,y+3,z);
    entity.player.start = true;
    entity.player.end = false;
    entity.player.canFly = false;
    zeroTime(entity);
};
save=(entity)=>{
    x = entity.position.x;
    y = entity.position.y;
    z = entity.position.z;
    entity.player.directMessage(`存档成功 用时：${maths.format(getTime(entity))} 秒`);
    entity.player.spawnPoint = MakePostion(x,y+3,z);
};
backrun=(entity)=>{
    entity.player.forceRespawn();
};
end=(entity)=>{
    entity.player.endTime = maths.format(getTime(entity));
    world.say(`${entity.player.name} 到达了终点！\n用时：${entity.player.endTime} 秒！`);
    entity.player.end = true;
    entity.player.start = !canAgain;
    entity.player.canFly = flyAfterEnd;
    zeroTime(entity);
};
warn=(entity)=>{entity.player.directMessage(`<!> 你不能碰玻璃 那是防止跳关的 <!>`);entity.position = MakePostion(maths.randomInt(117,121),10+5,maths.randomInt(44,48));};

module.exports = {
    save,
    backrun,
    start,
    end,
    warn
}